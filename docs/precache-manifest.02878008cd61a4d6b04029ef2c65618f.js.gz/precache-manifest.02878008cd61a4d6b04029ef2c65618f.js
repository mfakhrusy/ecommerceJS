self.__precacheManifest = [
  {
    "revision": "002764f899c2650fb396",
    "url": "main.css"
  },
  {
    "revision": "f7fbcb21a4e3d5cec121da48daa679e0",
    "url": "index.html"
  },
  {
    "revision": "002764f899c2650fb396",
    "url": "bundle.js"
  },
  {
    "url": "a581e65a3a79ef220f645a096d9f5c11.png"
  },
  {
    "revision": "54731d60be7d3222e813",
    "url": "0.bundle.js"
  }
];