self.__precacheManifest = [
  {
    "revision": "7069bc320a586843bdbb",
    "url": "main.css"
  },
  {
    "revision": "f7fbcb21a4e3d5cec121da48daa679e0",
    "url": "index.html"
  },
  {
    "revision": "7069bc320a586843bdbb",
    "url": "bundle.js"
  },
  {
    "url": "a581e65a3a79ef220f645a096d9f5c11.png"
  },
  {
    "revision": "7b6bff0f3381d1d98eb2",
    "url": "0.bundle.js"
  }
];