self.__precacheManifest = [
  {
    "revision": "3b13b13f498fcf2eef39",
    "url": "main.css"
  },
  {
    "revision": "c4b4af07295ab85dddaa24e6c18c3793",
    "url": "index.html"
  },
  {
    "revision": "3b13b13f498fcf2eef39",
    "url": "bundle.js"
  },
  {
    "url": "a581e65a3a79ef220f645a096d9f5c11.png"
  },
  {
    "revision": "816b18f744b3f615b205",
    "url": "0.bundle.js"
  }
];