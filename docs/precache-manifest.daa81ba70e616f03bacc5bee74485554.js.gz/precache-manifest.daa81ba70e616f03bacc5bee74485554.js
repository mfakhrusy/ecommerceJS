self.__precacheManifest = [
  {
    "revision": "5261383a8c8493c718cf",
    "url": "main.css"
  },
  {
    "revision": "f7fbcb21a4e3d5cec121da48daa679e0",
    "url": "index.html"
  },
  {
    "revision": "5261383a8c8493c718cf",
    "url": "bundle.js"
  },
  {
    "url": "a581e65a3a79ef220f645a096d9f5c11.png"
  },
  {
    "revision": "70d1e8d3773a73bffd85",
    "url": "0.bundle.js"
  }
];