self.__precacheManifest = [
  {
    "revision": "14b544080042f2ffcd1b",
    "url": "main.css"
  },
  {
    "revision": "c4b4af07295ab85dddaa24e6c18c3793",
    "url": "index.html"
  },
  {
    "revision": "14b544080042f2ffcd1b",
    "url": "bundle.js"
  },
  {
    "url": "a581e65a3a79ef220f645a096d9f5c11.png"
  },
  {
    "revision": "33121c5119a62b7cff12",
    "url": "0.bundle.js"
  }
];