self.__precacheManifest = [
  {
    "revision": "ef68c5658104787a2cc2",
    "url": "main.css"
  },
  {
    "revision": "f7fbcb21a4e3d5cec121da48daa679e0",
    "url": "index.html"
  },
  {
    "revision": "ef68c5658104787a2cc2",
    "url": "bundle.js"
  },
  {
    "revision": "b00cd3d1a4f3486c7c4d",
    "url": "0.bundle.js"
  }
];