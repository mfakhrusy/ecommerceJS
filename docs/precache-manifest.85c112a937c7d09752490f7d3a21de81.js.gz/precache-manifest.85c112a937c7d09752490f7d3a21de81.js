self.__precacheManifest = [
  {
    "revision": "82f8c9918c6a58cc66d3",
    "url": "main.css"
  },
  {
    "revision": "f7fbcb21a4e3d5cec121da48daa679e0",
    "url": "index.html"
  },
  {
    "revision": "82f8c9918c6a58cc66d3",
    "url": "bundle.js"
  },
  {
    "revision": "b00cd3d1a4f3486c7c4d",
    "url": "0.bundle.js"
  }
];